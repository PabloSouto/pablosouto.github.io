function registrar(){
    console.log('clic');
}